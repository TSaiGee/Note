---
typora-copy-images-to: assets
typora-root-url: assets
---

### 练习

用户表user、角色表role、用户角色关联表user_role、权限表menu、权限角色关联表menu_role

![1608276267446](/1608276267446.png)![1608276309904](/1608276309904.png)![1608276330719](/1608276330719.png)

![1608276621137](/1608276621137.png)![1608276628672](/1608276628672.png)

查询ID为1的医生的姓名，密码，以及拥有哪些角色

```mysql
select realname,password,rnameZh
from user u
join user_role ur
on u.id = ur.uid
join role r
on r.id = ur.rid
```

查询所有门诊医生信息

```mysql

```

查询ID为2的医生有哪些权限

```mysql

```

![1608276849886](/1608276849886.png)

查询出所有人的平均成绩

```mysql
select name,(math+english+chinese)/3
from student
```

![1608277265951](/1608277265951.png)

查询出所有1级类别及旗下的2级类别

```mysql
select c1.name,c2.name
from category c1
join category c2
on c1.id = c2.parentid
```


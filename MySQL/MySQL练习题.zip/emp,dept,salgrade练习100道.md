1.查询所有的部门编号：

```mysql
select deptno
from dept
```



2.查询所有有人的部门编号：

```mysql
select distinct deptno
from emp
```



3.查询所有岗位名称：

```mysql
select distinct job
from emp
```



4.查询所有薪水超过两千的员工信息

```mysql
select *
from emp
where sal > 2000
```



5.查询所有20部门的员工姓名，编号及薪水

```mysql
select ename,empno,sal
from emp
where deptno = 20
```



6.查询所有没有奖金的员工信息

```mysql
select *
from emp
where comm is null or comm = 0
```



7.查询所有有奖金的员工信息

```mysql
select *
from emp
where comm is not null and comm != 0
```



8.查询最高领导的员工信息

```mysql
select *
from emp
where mgr is null
```



9.查询所有1981年之后入职的员工信息

```mysql
select *
from emp
where hiredate > '1981-12-31'
```



10.查询所有薪水在2000-4000范围内的员工信息

```mysql
select *
from emp
where sal between 2000 and 4000
```



11.查询所有部门编号是10或30的员工信息

```mysql
select *
from emp
where deptno in (10,30)
```



12.查询所有20部门并且薪水超过2000的员工信息：

```mysql
select *
from emp
where deptno = 20 and sal > 2000
```



13.查询所有薪水不在2000-4000范围内的员工信息

```mysql
select *
from emp
where sal not between 2000 and 4000

select *
from emp
where sal < 2000 or sal > 4000
```



14.查询所有部门编号不是10，30的员工信息

```mysql
select *
from emp
where deptno not in (10,30)
```



15.查询用户名为scott的员工信息：注意区分大小写

```mysql
select *
from emp
where binary ename = 'scott'
```



16.查询姓名里面包含ALL的员工姓名

```mysql
select ename
from emp
where ename like '%ALL%'
```



17.查询所有以”S”开头的同学

```mysql
select *
from emp
where ename like 'S%'
```



18.查询第二个字母为A的员工姓名

```mysql
select ename
from emp
where ename like '_A%'
```



19.查询所有员工的编号、姓名、部门编号、职位、薪水，按照薪水降序排列

```mysql
select empno,ename,deptno,job,sal
from emp
order by sal desc
```



20.查询所有员工信息，按照部门降序排列，部门内按照薪水升序排列

```mysql
select *
from emp
order by deptno desc,sal asc
```



21.查询姓名中包含‘A’员工的姓名，编号，薪水，按照薪水降序排列

```mysql
select ename,empno,sal
from emp
where ename like '%A%'
order by sal desc
```



22.查询年收入超过10000的员工的姓名，编号，薪水，年收入(含奖金)，按照年收入降序排列

```mysql
select ename,empno,sal,(sal*12+ifnull(comm,0)) as total
from emp
where (sal*12+ifnull(comm,0)) > 10000
order by total desc
```



23.查询年薪超过10000的员工的姓名，编号，薪水，年收入，按照年薪降序排列

```mysql
select ename,empno,sal,sal*12 as total
from emp
where sal*12 > 10000
order by total desc
```



24.查询雇员表中，姓名为SMITH的雇员，截止到今天共工作了多少周，则可以使用如下的SQL语句

```mysql
select TIMESTAMPDIFF(week,hiredate,now())
from emp
where ename ='SMITH'
```



25.查询各部门的最高薪水、最低薪水、平均薪水…..

```mysql
select max(sal),min(sal),avg(sal)
from emp
group by deptno
```



26.查询‘SMITH’的领导姓名

```mysql
select ename
from emp
where empno = (select mgr from emp where ename = 'SMITH')

select m.ename
from emp e
join emp m
on e.mgr = m.empno
where e.ename = 'SMITH'
```



27.查询部门名称是‘SALES’的员工信息

```mysql
select e.*
from emp e
join dept d
on e.deptno = d.deptno
where dname = 'SALES'

select *
from emp
where deptno in (select deptno from dept where dname = 'SALES')
```



28.查询公司中薪水最高的员工信息

```mysql
select *
from emp
where sal = (select max(sal) from emp)

select *
from emp e
where (select count(empno) from emp where sal > e.sal) = 0
```



29.查询公司所有员工的个数

```mysql
select count(empno)
from emp
```



30.查询公司中最高薪水是多少

```mysql
select max(sal) from emp
```



31.查询公司中平均奖金是多少

```mysql
select avg(comm)
from emp

select avg(ifnull(comm,0))
from emp
```



32.查询公司中最晚入职的时间

```mysql
select max(hiredate) from emp
```



33.查询公司中有奖金的人数.

```mysql
select count(comm)
from emp
where comm != 0 and comm is not null
```



34.查询20部门的最高薪水是多少.

```mysql
select max(sal)
from emp
where deptno = 20
```



35.查询各部门的平均薪水及部门编号，部门名称。

```mysql
select avg(sal) as avgsal,d.deptno,dname
from emp e
join dept d
on e.deptno = d.deptno
group by d.deptno,dname
```



36.查询各部门中最高薪水的员工编号，姓名…

```mysql
select empno,ename
from emp e
where (deptno,sal) in (select deptno,max(sal) as maxsal from emp group by deptno)

select empno,ename
from emp e
join (select deptno,max(sal) as maxsal from emp group by deptno) a
on e.deptno = a.deptno
where sal = maxsal

select empno,ename
from emp e
where (select count(empno) from emp where deptno = e.deptno and sal > e.sal) = 0
```



37.查询所有员工姓名中包含‘A’的最高薪水

```mysql
select max(sal)
from emp
where ename like '%A%'
```



38.查询各岗位的最高薪水，最低薪水。要求只统计薪水>1000的

```mysql
select max(sal),min(sal)
from emp
where sal > 1000
group by job
```



39.查询各部门的平均薪水及部门编号，要求只列出平均薪水>2000

```mysql
select avg(sal) as avgsal,deptno
from emp
group by deptno
having avgsal > 2000
```



40.查询各部门的平均薪水及部门编号，要求只有员工姓名中包含‘A’才参与统计，只列出平均薪水>1500的，按照平均薪水降序排列

```mysql
select avg(sal) as avgsal,deptno
from emp
where ename like '%A%'
group by deptno
having avgsal > 1500
order by avgsal desc
```



41.查询各部门最高薪水的员工信息

```mysql
select *
from emp e
where (deptno,sal) in (select deptno,max(sal) as maxsal from emp group by deptno)

select *
from emp e
join (select deptno,max(sal) as maxsal from emp group by deptno) a
on e.deptno = a.deptno
where sal = maxsal

select *
from emp e
where (select count(empno) from emp where deptno = e.deptno and sal > e.sal) = 0
```



42.查询最高薪水的员工信息

```mysql
select *
from emp
where sal = (select max(sal) from emp)

select *
from emp e
where (select count(empno) from emp where sal > e.sal) = 0
```



43.查询薪水大于该部门平均薪水的员工信息

```mysql
select e.*
from emp e
join (select deptno,avg(sal) as avgsal
			from emp
			group by deptno) a
on e.deptno = a.deptno
where sal > avgsal
```



44.查询最高薪水的员工信息

```mysql
select *
from emp
where sal = (select max(sal) from emp)

select *
from emp e
where (select count(empno) from emp where sal > e.sal) = 0
```



45.查询各部门最高薪水的员工信息

```mysql
select *
from emp e
where (deptno,sal) in (select deptno,max(sal) as maxsal from emp group by deptno)

select *
from emp e
join (select deptno,max(sal) as maxsal from emp group by deptno) a
on e.deptno = a.deptno
where sal = maxsal

select *
from emp e
where (select count(empno) from emp where deptno = e.deptno and sal > e.sal) = 0
```



46.查询‘SMITH’的领导姓名

```mysql
select ename
from emp
where empno = (select mgr from emp where ename = 'SMITH')

select m.ename
from emp e
join emp m
on e.mgr = m.empno
where e.ename = 'SMITH'
```



47.查询部门名称是‘SALES’的员工信息

```mysql
select e.*
from emp e
join dept d
on e.deptno = d.deptno
where dname = 'SALES'

select *
from emp
where deptno in (select deptno from dept where dname = 'SALES')
```



48.查询公司中薪水最高的员工信息

```mysql
select *
from emp
where sal = (select max(sal) from emp)

select *
from emp e
where (select count(empno) from emp where sal > e.sal) = 0
```



49.查询薪水等级为4的员工信息

```mysql
select e.*
from emp e
join salgrade 
on sal between losal and hisal
where grade = 4
```



50.查询领导者是‘BLAKE’的员工信息

```mysql
select e.*
from emp e
join emp m
on e.mgr = m.empno
where m.ename = 'BLAKE'

select *
from emp
where mgr in (select empno from emp where ename = 'BLAKE')
```



51.查询最高领导者的薪水等级

```mysql

```



52.查询薪水最低的员工信息

```mysql

```



53.查询和SMITH工作相同的员工信息

```mysql

```



54.查询不是领导的员工信息

```mysql

```



55.查询平均工资比10部门低的部门编号

```mysql

```



56.查询在纽约工作的所有员工

```mysql

```



57.查询‘SALES’部门平均薪水的等级

```mysql

```



58.查询10号部门的员工在整个公司中所占的比例：

```mysql

```



59.emp显示前5条。

```mysql

```



60.查询各部门工资大于该部门平均工资的员工信息：

```mysql

```



61.查询各岗位工资小于该岗位平均工资的员工信息；

```mysql

```



62.查询所有领导的信息：要求使用exists关键字

```mysql

```



63.查询所有员工的姓名，薪水，部门名称

```mysql

```



64.查询所有员工的姓名，薪水，部门名称,薪水等级

```mysql

```



65.查询员工姓名及领导者姓名

```mysql

```



66.查询所有员工的姓名，部门名称

```mysql

```



67.查询员工表中工资大于1600的员工的姓名和工资

```mysql

```



68.查询员工表中员工号是17的员工的姓名和部门编号

```mysql

```



69.选择员工表中工资不在4000到5000内的员工的姓名和工资.

```mysql

```



70.选择员工表中在20和30部门工作的员工的姓名和部门号

```mysql

```



71.选择员工表中没有管理者的员工姓名及职位，按职位排序.

```mysql

```



72.选择员工表中有奖金的员工姓名，工资和奖金，按工资倒序排列

```mysql

```



73.选择员工表中员工姓名的第三个字母是A的员工姓名

```mysql

```



74.列出部门表中的部门名称和所在城市

```mysql

```



75.显示员工表中的不重复的岗位job

```mysql

```



76.连接员工表中的员工姓名、职位、薪水，列之间用逗号连接，列头显示成out_put

```mysql

```



77.查询员工表中员工号，姓名，工资，以及工资提高百分之20之后的结果

```mysql

```



78.查询员工的姓名和工资数，条件限定为工资数必须大于1200，并且查询结果按入职时间进行排序。早入职的员工排在前面

```mysql

```



79.列出除了'ACCOUNTING'部门之外还有什么部门

```mysql

```



80.把雇员按部门分组，求最高薪水，部门号 要求过滤掉名字中第二个字母是’A’的员工， 并且部门的平均薪水 > 3000,按照部门编号倒序排列

```mysql

```



81.求工作职位是’manager’的员工姓名，部门名称和薪水等级

```mysql

```



82.按照部门分组统计，求最高薪水，平均薪水，最低薪水，只有薪水是1200以上的员工才参与统计，并且分组结果中只包含平均薪水在1500以上的部门，并且按照平均薪水倒序排列

```mysql

```



83.求薪水最高的员工姓名

```mysql

```



84.查询各部门平均薪水等级，并且按平均薪水等级的降序排列

```mysql

```



85.查询所有员工姓名以S或s开头的所有员工信息

```mysql

```



86.查询所有工作时间超过一年的员工编号，姓名及入职时间,要求雇用时间的格式为’yyyy年mm月dd日’

```mysql

```



87.查询20部门的所有员工的员工姓名，实际收入

```mysql

```



88.查询10部门工资大于3000的员工信息，要求按员工的入职时间由前到后排序

```mysql

```



89.查询10部门或20部门的所有员工的姓名，并截取前三位，按员工姓名升序排列

```mysql

```



90、查询所有员工的姓名，要求所有员工的姓名显示成小写，雇用日期显示为”yyyy-mm-dd”这种格式

```mysql

```



91、查询所有员工的姓名，所在部门名称，薪水，薪水等级、直接领导的姓名 （有问题，不显示最高领导）

```mysql

```



92、查询部门名称是’ACCOUNTING’的员工姓名及薪水等级

```mysql

```



93、不能使用组函数，查询薪水的最高值.

```mysql

```



94、统计平均薪水最高的部门名称

```mysql

```



95、查询平均薪水等级最低的部门名称

```mysql

```



96、查询平均薪水最低的部门名称，要求：只有领导才参加统计

```mysql

```



97、查询比普通员工的最高薪水还要高的领导者姓名

```mysql

```



98、找出薪水最高的五个人

```mysql

```



99、查询第2到第7名的员工，按薪水降序排列

```mysql

```



100、查询最后入职的5名员工

```mysql

```


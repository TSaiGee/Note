---

typora-root-url: assets
typora-copy-images-to: assets
---

## MySQL周测练习

#### 编程题(每题每问5分)

###### 1.以emp,dept,salgrade表为例，请写出下列代码

- 1.查询出所有员工的姓名，工资，部门名称

  ```mysql
  
  ```

- 2.查询出30部门的员工姓名，入职日期，奖金，要求奖金不能为空

  ```mysql
  
  ```

- 3.查询出工作地点在NEW YORK的员工姓名，工资，部门编号，按照工资降序排序

  ```mysql
  
  ```

- 4.查询出20部门，工资比JONES高的员工信息

  ```mysql
  
  ```

- 5.查询出不在30部门工作的员工姓名

  ```mysql
  
  ```

- 6.查询出姓名中包含A的员工姓名，部门名称

  ```mysql
  
  ```

- 7.查询出每个部门的编号，名称，平均工资

  ```mysql
  
  ```

- 8.查询出人数5人以上的部门编号，名称，平均工资

  ```mysql
  
  ```

- 9.将20部门中入职日期1981年以前的员工工资上调100

  ```mysql
  
  ```

- 10.删除员工编号为9527的员工信息

  ```mysql
  
  ```

- 11.查询出10部门的员工姓名，入职日期（要求格式:xxxx年xx月xx日）

  ```mysql
  
  ```

- 12.查询出所有员工的姓名，工资，部门名称，工资等级，要求只显示工资等级2以上的

  ```mysql
  
  ```

  

###### 2.完成下列要求

**tab_userinfo用户信息表**

| uid  | nickname用户昵称（姓名） | password用户密码 |
| ---- | ------------------------ | ---------------- |
| 1    | tom                      | 99999            |
| 2    | bob                      | 66666            |
| 3    | allen                    | 54321            |
| ...  | ...                      | ...              |

**tab_category文章类别表**

| tid  | tname |
| ---- | ----- |
| 100  | 言情  |
| 101  | 科普  |
| 102  | 体育  |
| ...  | ...   |

**tab_article文章表**

| aid  | title文章标题 | uid作者id | viewnum浏览量 | tid类别id | content文章内容   |
| ---- | ------------- | --------- | ------------- | --------- | ----------------- |
| 1001 | 活着          | 1         | 9777          | 100       | 汤姆进行着...     |
| 1002 | 智能时代      | 2         | 1000101       | 101       | 随着信息时代...   |
| 1003 | 编程之美      | 1         | 32            | 101       | 编程语言千千万... |
| ...  | ...           | ...       | ...           | ...       | ...               |

**tab_reply文章评论表**

| rid    | uid评论者id | aid被评论文章id | content评论内容   | rtime评论时间     |
| ------ | ----------- | --------------- | ----------------- | ----------------- |
| 900001 | 1           | 1001            | 赞...             | 2019-9-3 11:35:27 |
| 900002 | 2           | 1001            | 楼主说的对...     | 2019-9-4 09:30:57 |
| 900003 | 1           | 1002            | 路过...           | 2019-9-1 07:44:18 |
| 900003 | 3           | 1002            | 哈哈...           | 2019-9-2 17:30:56 |
| 900003 | 2           | 1003            | 对对对，是是是... | 2019-9-3 22:40:32 |
| ...    | ...         | ...             | ...               | ...               |

###### ① 查询出 tom用户写过的所有文章标题，浏览量

```mysql
select title,viewnum
from tab_userinfo u
join tab_article a
on u.uid = a.uid
where nickname = 'tom'
```

###### ② 查询出文章标题为 “智能时代”的所有评论者姓名 

```mysql
select nickname
from tab_userinfo u
join tab_reply r
on u.uid = r.uid
where r.aid in (select aid from tab_article where title = '智能时代')

select nickname
from tab_userinfo u
join tab_reply r
on u.uid = r.uid
join tab_article a
on a.aid = r.aid
where title = '智能时代'
```

###### ③ 查询出所有文章的标题，浏览量，从属类别名称

```mysql
select title,viewnum,tname
from tab_article a
join tab_category c
on c.tid = a.tid
```

###### ④ 查询出文章浏览量前3的文章标题，作者姓名

```mysql
select title,nickname
from tab_article a
join tab_userinfo u
on u.uid = a.uid
order by viewnum desc
limit 0,3
```

###### ⑤ 查询出bob所有评论的文章标题，评论内容

```mysql
select title,content
from tab_article a
join tab_reply r
on a.aid = r.aid
where r.uid in (select uid from tab_userinfo where nickname = 'bob')

select title,content
from tab_article a
join tab_reply r
on a.aid = r.aid
join tab_userinfo u
on u.uid = r.uid
where nickname = 'bob'
```



###### 3.完成下图要求

![1567672604321](/1567672604321.png)

```mysql
select name
from score
group by name
having min(score) > 80

select name
from score
where name not in (select name from score where score <= 80)
```



###### 4.完成下列要求

![1567672706414](/1567672706414.png)



![1567672746024](/1567672746024.png)

```mysql
insert into s values (10,'张三');
delete from s where sno = 10 and sname = '张三';
update s set sno = 11 where sno = 10 and sname = '张三';
select * from s where sno = 10 and sname = '张三';
```

```mysql
select *
from s
where sno not in (select sno 
              	  from sc
              	  where cno in (select cno from c where cteacher = '李明'))
```



###### 5.有如下关系请按照要求写出代码

**学生表student**

| id   | stuname | sex  |
| ---- | ------- | ---- |
| 1001 | 张三    | 男   |
| 1002 | 李四    | 女   |
| 1003 | 张三    | 男   |
| 1004 | 王五    | 女   |
| ...  | ...     | ...  |

删除表中记录，要求：删除stuname相同的记录，但要保留id最小的一条

```mysql
delete from student
where id not in (select min(id) from student group by stuname)

delete from student
where id not in (select * from (select min(id) from student group by stuname) a)
```

查询名字出现3次以上的学员姓名

```mysql
select name
from emp
group by name
having count(id) > 3
```

